function showGreeting() {
    const hour = new Date().getHours();
    let greeting = "Hello!";
    if (hour < 12) greeting = "Good morning!";
    else if (hour < 18) greeting = "Good afternoon!";
    else greeting = "Good evening!";
    document.getElementById("greeting").innerText = greeting;
  }
  
  function validateForm() {
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10}$/;
    if (!emailRegex.test(email)) {
      alert("Invalid email");
      return false;
    }
    if (!phoneRegex.test(phone)) {
      alert("Invalid phone number");
      return false;
    }
    return true;
  }
  
  function toggleDetails(id) {
    const elem = document.getElementById(id);
    if (elem.style.display === "none") {
      elem.style.display = "block";
    } else {
      elem.style.display = "none";
    }
  }
  